package com.senanur.recipeapp.interfaces


import retrofit2.Call
import retrofit2.http.GET
import java.util.Locale.Category

interface GetDataService {
    @GET("categories.php")
    fun getCategoryList(): Call<Category>
}