package com.senanur.recipeapp.entities


import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.senanur.recipeapp.entities.converter.CategoryListConverter

@Entity(tableName = "CategoryItems")

data class CategoryItems(
    @PrimaryKey(autoGenerate = true)
    var id:Int,


    @ColumnInfo(name = "idCategory")
    val idCategory: String,

    @ColumnInfo(name = "strCategory")
    val strCategory: String,

    @ColumnInfo(name = "strCategoryDescription")
    val strCategoryDescription: String,

    @ColumnInfo(name = "strCategoryThumb")
    val strCategoryThumb: String
)


