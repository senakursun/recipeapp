package com.senanur.recipeapp

import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.senanur.recipeapp.adapter.MainCategoryAdapter
import com.senanur.recipeapp.adapter.SubCategoryAdapter
import com.senanur.recipeapp.database.RecipeDatabase
import com.senanur.recipeapp.entities.Recipes
import kotlinx.android.synthetic.main.activity_home.rv_main_category
import kotlinx.android.synthetic.main.activity_home.rv_sub_category
import kotlinx.coroutines.launch

class HomeAcivity : BaseActivity() {
    var arrMainCategory = ArrayList<CategoryItems>()
    var arrSubCategory = ArrayList<Recipes>()

    var mainCategoryAdapter = MainCategoryAdapter()
    var subCategoryAdapter = SubCategoryAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)


        getDataFromDb()


        arrSubCategory.add(Recipes(1,"Beef and mustard pie"))
        arrSubCategory.add(Recipes(2,"Chicken and mushroom hotpot"))
        arrSubCategory.add(Recipes(3,"Banana pancakes"))
        arrSubCategory.add(Recipes(4,"kapsalon"))


        subCategoryAdapter.setData(arrSubCategory)



        rv_sub_category.layoutManager = LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false)
        rv_sub_category.adapter = subCategoryAdapter
    }


    private fun getDataFromDb(){
        launch {
            this.let {
                var cat = RecipeDatabase.getDatabase(this@HomeAcivity).recipeDao().getAllCategory()
                arrMainCategory = cat as ArrayList<CategoryItems>
                arrMainCategory.reverse()
                mainCategoryAdapter.setData(arrMainCategory)
                rv_main_category.layoutManager = LinearLayoutManager(this@HomeAcivity,LinearLayoutManager.HORIZONTAL,false)
                rv_main_category.adapter = mainCategoryAdapter

            }

        }
    }




}